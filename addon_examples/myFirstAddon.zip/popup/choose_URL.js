
let LINKS = {
  "Browser Toolbar Button": "https://developer.mozilla.org/en-US/Add-ons/WebExtensions/user_interface/Browser_action",
  "Browser Toolbar Button Popup": "https://developer.mozilla.org/en-US/Add-ons/WebExtensions/user_interface/Popups",
  "想看更多範例程式碼嗎？": "https://github.com/mdn/webextensions-examples",
  "WebExtensions 文件": "https://developer.mozilla.org/en-US/Add-ons/WebExtensions",
  "試試不同的 Firefox 吧!": "https://www.mozilla.org/zh-TW/firefox/channel/desktop/",
};

function nameToURL(title) {
  return LINKS[title];
}

document.addEventListener("click", (e) => {
  if (e.target.classList.contains("openURL")) {
    browser.tabs.create({
      url: nameToURL(e.target.textContent),
    });
  }
});

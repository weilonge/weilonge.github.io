
browser.contextMenus.create({
  id: "show",
  title: "Show a notification"
});

browser.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId == "show") {
    let title = "My Addon";
    let content = "notifications";
    browser.notifications.create({
      "type": "basic",
      "iconUrl": browser.extension.getURL("icons/icon-32.png"),
      "title": title,
      "message": content
    });
  }
});

browser.tabs.onCreated.addListener(tab => {
  browser.pageAction.show(tab.id);
});

browser.notifications.onClicked.addListener(() => {
  browser.tabs.create({
    url: "https://developer.mozilla.org/en-US/Add-ons/WebExtensions/user_interface/Notifications",
  });
});




window.addEventListener('DOMContentLoaded', () => {
  const btnStart = document.getElementById('start');
  const btnStop = document.getElementById('stop');
  const btnSort = document.getElementById('sort');
  const tableBody = document.querySelector('div.contents > table.table > tbody');

  let timer
  btnStart.addEventListener('click', () => {
    clearInterval(timer);
    timer = setInterval(() => {
      render(TABLE_DATA, tableBody, true);
    }, 1000);
  });

  btnStop.addEventListener('click', () => {
    clearInterval(timer);
  });

  btnSort.addEventListener('click', () => {
    clearInterval(timer);
    render(TABLE_DATA, tableBody, false);
  });

  function render(originalData, container, random) {
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    if (random) {
      shuffle(originalData);
    } else {
      originalData.sort((a, b) => b.price - a.price);
    }
    let body = document.createDocumentFragment();
    for (let i of originalData) {
      let item = document.createElement('tr');

      let tdId = document.createElement('td');
      tdId.textContent = i.id;

      let tdName = document.createElement('td');
      tdName.textContent = i.name;

      let tdThumbnail = document.createElement('td');
      let image = document.createElement('img');
      image.src = i.thumbnailUrl;
      tdThumbnail.appendChild(image);

      let tdPrice = document.createElement('td');
      tdPrice.textContent = i.price;

      item.appendChild(tdId);
      item.appendChild(tdName);
      item.appendChild(tdThumbnail);
      item.appendChild(tdPrice);
      body.appendChild(item);
    }
    container.append(body);
  }

  function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;
    while (0 !== currentIndex) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }
    return array;
  }

  render(TABLE_DATA, tableBody);
});

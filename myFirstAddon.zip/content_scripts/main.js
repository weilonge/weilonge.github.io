function messageHandler(request, sender, sendResponse) {
  window.open(request.openURL); 
}

browser.runtime.onMessage.addListener(messageHandler);

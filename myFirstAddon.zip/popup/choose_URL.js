function nameToURL(title) {
  switch (title) {
    case "想看更多範例程式碼嗎？":
      return "https://github.com/mdn/webextensions-examples";
    case "WebExtensions 文件":
      return "https://developer.mozilla.org/en-US/Add-ons/WebExtensions";
    case "試試不同的 Firefox 吧!":
      return "https://www.mozilla.org/zh-TW/firefox/channel/desktop/";
  }
}

document.addEventListener("click", (e) => {
  if (e.target.classList.contains("openURL")) {
    browser.tabs.create({
      url: nameToURL(e.target.textContent),
    });
  }
});

function showDicDialog(dicDom) {
  chrome.runtime.sendMessage({dicDom: dicDom}, response => {
    if ('ok' !== response.status) {
      console.error('ERROR: chrome.runtime.sendMessage');
    }
  });
  let iframeUrl = chrome.extension.getURL('contentScripts/dicIframe.html');
  let dicallWrapper = document.getElementById('dicallWrapper');
  let iframe = document.createElement('iframe');
  iframe.id  = 'dicallPanel';
  iframe.src = iframeUrl;
  iframe.scrolling = 'no';
  dicallWrapper.appendChild(iframe);
}

function hideDicDialog() {
  let dicallWrapper = document.getElementById('dicallWrapper');
  while (dicallWrapper.firstChild) {
    dicallWrapper.removeChild(dicallWrapper.firstChild);
  }
}

function init() {
  Dical.init(showDicDialog, hideDicDialog);
  let dicallWrapper = document.getElementById('dicallWrapper');
  if (!dicallWrapper) {
    let wrapper = document.createElement('div');
    wrapper.id = 'dicallWrapper';
    document.body.appendChild(wrapper);
  }
}

// "interactive" readyState happens during DOMContentLoaded event, and
// "complete" readyState is after that. BTW, "loaded" happens before
// DOMContentLoaded.
if (document.readyState === "complete" ||
  document.readyState === "interactive") {
  init();
} else {
  document.addEventListener('DOMContentLoaded', init);
}


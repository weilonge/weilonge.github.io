function writeHtml(dicDomString) {
  let dicResult = document.getElementById('dicResult');
  let parser = new DOMParser();
  dicDom = parser.parseFromString(dicDomString, 'text/html');
  while (dicResult.firstChild) {
    dicResult.removeChild(dicResult.firstChild);
  }
  dicResult.appendChild(dicDom.body.children[0]);
  dicResult.scrollTop = 0;
}

function showDicDialog(dicDomString) {
  writeHtml(dicDomString);
}

function hideDicDialog() {
}

document.addEventListener('DOMContentLoaded', event => {
  chrome.runtime.sendMessage({}, response => {
    writeHtml(response.dicDom);
  });
  Dical.init(showDicDialog, hideDicDialog);
});
